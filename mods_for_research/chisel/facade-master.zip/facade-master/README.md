# facade
Adds decorative clay and stone-type nodes to Minetest Game.
![Preview](https://github.com/TumeniNodes/facade/blob/master/screenshot.png)
![Preview](https://github.com/TumeniNodes/facade/blob/master/screenshot2.png)
![Preview](https://github.com/TumeniNodes/facade/blob/master/screenshot3.png)
![Preview](https://github.com/TumeniNodes/facade/blob/master/screenshot4.png)
