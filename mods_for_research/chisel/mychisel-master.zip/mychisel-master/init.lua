chisel = {}


dofile(minetest.get_modpath("mychisel").."/chisel.lua")
dofile(minetest.get_modpath("mychisel").."/nodes.lua")








