Agriculture Mod

![](http://jbbgameich.github.io/file/image/agriculture_all_plants.png)

Code (WTFPL):
 * Copyright (C) 2015-2018 JBB
 * Copyright (C) 2017-2018 MBB
 * Copyright (C) 2016-2019 Linus Jahn <lnj@kaidan.im>

Textures (CC BY-SA 4.0):
 * Copyright (C) 2015-2016 JBB
 * Copyright (C) 2017-2018 MBB
